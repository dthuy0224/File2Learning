# ⚡ Google Colab - Quick Start (5 phút)

## 🎯 TL;DR - Training AI Model trên Colab

```
1. Zip folder backend/ → backend.zip
2. Upload File2Learning_Colab_Training.ipynb lên Colab
3. Enable GPU (Runtime → Change runtime type → GPU)
4. Run All cells
5. Download trained model (~10 phút sau)
6. Extract và copy vào backend/models/difficulty_classifier/
```

---

## 📝 Step-by-Step (Chi tiết)

### 1️⃣ Chuẩn bị File (2 phút)

**Windows PowerShell:**
```powershell
cd "d:\The Last Dances\ATI\Final\File2Learning"
Compress-Archive -Path backend -DestinationPath backend.zip
```

**Hoặc dùng WinRAR/7-Zip:**
- Right-click folder `backend/` → Add to archive → `backend.zip`

---

### 2️⃣ Upload lên Colab (1 phút)

1. Vào: https://colab.research.google.com
2. **File** → **Upload notebook**
3. Chọn: `backend/File2Learning_Colab_Training.ipynb`

---

### 3️⃣ Enable GPU (30 giây)

```
Runtime → Change runtime type → Hardware accelerator → GPU → Save
```

---

### 4️⃣ Run Training (10 phút)

**Option 1: Run All (Recommended)**
```
Runtime → Run all
```

**Option 2: Run từng cell**
- Shift + Enter để chạy mỗi cell

**Trong quá trình chạy:**
- Cell 6: Upload file `backend.zip` khi được yêu cầu
- Cell 8: Đợi training (~8-12 phút)
- Cell 11: Auto download model

---

### 5️⃣ Download & Integrate (2 phút)

File `file2learning_trained_model.zip` sẽ tự động download

**Extract và copy:**
```bash
# Extract ZIP
# Copy all contents to: backend/models/difficulty_classifier/
```

**Verify:**
```bash
cd backend
python -c "from app.ai.models.difficulty_classifier import DifficultyClassifier; print('✅ Model OK')"
```

---

## 📊 Expected Output

```
✅ GPU Available: Tesla T4
📊 GPU Memory: 15.89 GB
🚀 Training for 3 epochs...
Epoch 1/3 ━━━━━━━━━━━━━━ 100%
Epoch 2/3 ━━━━━━━━━━━━━━ 100%
Epoch 3/3 ━━━━━━━━━━━━━━ 100%
✅ New best model saved! F1: 0.8245
✅ Training Complete!
⏱️  Total time: 9.47 minutes
```

---

## 🔥 Pro Tips

### Faster Upload
Nếu `backend.zip` quá lớn (>100MB):
```python
# Option: Clone from GitHub thay vì upload
!git clone https://github.com/YOUR_USERNAME/File2Learning.git
```

### Keep Session Alive
Colab có idle timeout 90 phút. Để tránh disconnect:
```python
# Run cell này (trong notebook mới):
import time
while True:
    time.sleep(60)
    print(".", end="")
```

### Monitor GPU Usage
```python
# Thêm cell này để monitor:
!nvidia-smi -l 2
```

---

## ⚠️ Common Issues

| Issue | Fix |
|-------|-----|
| GPU not available | Runtime → Change runtime type → GPU |
| Out of memory | Cell 14: Giảm `batch_size: 16` → `8` |
| Upload failed | Check `backend.zip` structure, phải có `app/ai/` |
| Session timeout | Chạy lại từ cell 8 (training) |

---

## 📦 Output Files

```
file2learning_trained_model.zip
├── best_model.pt              (~250MB)
├── training_curves.png
├── confusion_matrix.png
└── checkpoint_epoch_*.pt      (optional)
```

---

## 🚀 Why Colab?

**vs Local RTX 3050:**
- ⚡ **2-3x faster** (T4 16GB vs 3050 4GB)
- 💰 **Free** (no electricity cost)
- 🖥️ **Machine free** (can work on other tasks)
- 🎮 **No OOM risk** (16GB VRAM)

**Trade-off:**
- ⏰ Max 12h session
- 🌐 Requires internet
- 📦 Need to upload/download files

---

## 🎓 Next Steps

After training on Colab:
1. ✅ Model downloaded & integrated
2. 🧪 Test locally: `python -m app.ai.training.train_difficulty`
3. 🔗 Integrate vào document processing
4. 📈 Monitor performance với real data
5. 🔄 Retrain khi có more data

---

## 📞 Need Help?

See full guide: `COLAB_TRAINING_GUIDE.md`

**Time Estimate:**
- First time: ~15-20 phút (including reading)
- Subsequent runs: ~5-10 phút

**Good luck! 🚀**

