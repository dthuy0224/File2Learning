"""
Utility functions for AI training and inference
"""

