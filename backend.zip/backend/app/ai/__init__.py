"""
AI Module for File2Learning
Contains custom trained models and training utilities
"""

__version__ = "1.0.0"

